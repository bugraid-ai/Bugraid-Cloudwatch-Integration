const {
  CloudWatchClient,
  DescribeAlarmsCommand,
  PutMetricAlarmCommand,
} = require("@aws-sdk/client-cloudwatch");
const https = require("https");
const url = require("url");

/**
 * Will add the BugRaid Topic to all
 * enabled CloudWatch Alarms
 */
module.exports.handler = async (event, context) => {
  // Placeholder for results from processing event
  let responseStatus;
  let responseReason;

  console.log(event);

  try {
    // Identifies a CloudFormation Invocation
    if (
      (event.RequestType && event.RequestType === "Create") ||
      event.RequestType === "Update"
    ) {
      console.log("Adding Topic...");
      await addTopicToAlarms();
    } else if (event.RequestType === "Delete") {
      await removeTopicFromAlarms();
    }

    // Identifies an Event Rule Invocation
    if (event.source && event.source === "aws.events") {
      await addTopicToAlarms();
    }

    responseStatus = "SUCCESS";
  } catch (error) {
    responseStatus = "FAILED";
    responseReason = error.message;
  }

  // Send cfResponse only if a cf request
  if (event.RequestType) {
    try {
      const response = await cfResponse(
        event,
        context,
        responseStatus,
        responseReason
      );
      console.log(`CloudFormation Response: ${response}`);
    } catch (error) {
      console.log(`CloudFormation Response Error: ${error}`);
    }
  } else {
    return { status: responseStatus };
  }
};

const CloudWatch = new CloudWatchClient();

/**
 * Adds the BugRaid Topic to all
 * enabled CloudWatch Alarms
 */
const addTopicToAlarms = async () => {
  // Get alarms
  let alarms = await getAlarms();

  // Filter alarms
  alarms = alarms.filter(alarmFilter);

  // Add BugRaid Topic to alarms
  alarms = addBugRaidTopic(alarms);

  const results = await updateAlarms(alarms);

  // Check results for any errors
  results.forEach((result) => {
    if (result.error) {
      throw Error(result.error);
    }
  });

  console.log(`Updated alarms: ${JSON.stringify(alarms)}`);
};

/**
 * Removes the BugRaid Topic from
 * all the CloudWatch Alarms if it exists
 */
const removeTopicFromAlarms = async () => {
  // Get alarms
  let alarms = await getAlarms();

  // Removing BugRaid Topic from Alarms
  alarms = removeBugRaidTopic(alarms);

  const results = await updateAlarms(alarms);

  // Check results for any errors
  results.forEach((result) => {
    if (result.error) {
      throw Error(result.error);
    }
  });
};

/**
 * Constructs an array of trimmed down
 * CloudWatch Alarms for use in updating
 * the alarms with the BugRaid topic
 * @param {Array} alarms CloudWatch Alarms
 * @returns {Array} CloudWatch Alarms with BugRaid Topic
 */
const addBugRaidTopic = (alarms) => {
  const updatedAlarms = [];

  // Add the BugRaid Topic to any alarm
  // that does not already have it
  alarms.forEach((alarm) => {
    let updated = false;

    // Trim out unwanted properties
    const {
      AlarmArn,
      AlarmConfigurationUpdatedTimestamp,
      StateValue,
      StateReason,
      StateReasonData,
      StateUpdatedTimestamp,
      StateTransitionedTimestamp,
      ...updatedAlarm
    } = alarm;

    // Will cause error if empty array is present for this property
    if (updatedAlarm.Metrics?.length === 0) {
      delete updatedAlarm.Metrics;
    }

    if (updatedAlarm.Dimensions?.length === 0) {
      delete updatedAlarm.Dimensions;
    }

    // Confirm our topic does not already exist
    if (!updatedAlarm.OKActions.includes(process.env.TOPICARN)) {
      updatedAlarm.OKActions.push(process.env.TOPICARN);
      updated = true;
    }

    if (!updatedAlarm.AlarmActions.includes(process.env.TOPICARN)) {
      updatedAlarm.AlarmActions.push(process.env.TOPICARN);
      updated = true;
    }

    if (!updatedAlarm.InsufficientDataActions.includes(process.env.TOPICARN)) {
      updatedAlarm.InsufficientDataActions.push(process.env.TOPICARN);
      updated = true;
    }

    if (updated) {
      updatedAlarms.push(updatedAlarm);
    }
  });

  return updatedAlarms;
};

/**
 * Constructs an array of trimmed down
 * CloudWatch Alarms for use in updating
 * the alarms without the BugRaid Topic
 * @param {Array} alarms CloudWatch Alarms
 * @returns {Array} CloudWatch Alarms without BugRaid Topic
 */
const removeBugRaidTopic = (alarms) => {
  const updatedAlarms = [];

  // Add the BugRaid Topic to any alarm
  // that does not already have it
  alarms.forEach((alarm) => {
    let updated = false;

    // Trim out unwanted properties
    const {
      AlarmArn,
      AlarmConfigurationUpdatedTimestamp,
      StateValue,
      StateReason,
      StateReasonData,
      StateUpdatedTimestamp,
      StateTransitionedTimestamp,
      ...updatedAlarm
    } = alarm;

    // Will cause error if empty array is present for this property
    if (updatedAlarm.Metrics?.length === 0) {
      delete updatedAlarm.Metrics;
    }

    if (updatedAlarm.Dimensions?.length === 0) {
      delete updatedAlarm.Dimensions;
    }

    // Confirm our topic does not already exist
    if (updatedAlarm.OKActions.includes(process.env.TOPICARN)) {
      updatedAlarm.OKActions = updatedAlarm.OKActions.filter(
        (action) => action !== process.env.TOPICARN
      );
      updated = true;
    }

    if (updatedAlarm.AlarmActions.includes(process.env.TOPICARN)) {
      updatedAlarm.AlarmActions = updatedAlarm.AlarmActions.filter(
        (action) => action !== process.env.TOPICARN
      );
      updated = true;
    }

    if (updatedAlarm.InsufficientDataActions.includes(process.env.TOPICARN)) {
      updatedAlarm.InsufficientDataActions =
        updatedAlarm.InsufficientDataActions.filter(
          (action) => action !== process.env.TOPICARN
        );
      updated = true;
    }

    if (updated) {
      updatedAlarms.push(updatedAlarm);
    }
  });

  return updatedAlarms;
};

/**
 * Processes each alarm by posting to the
 * CloudWatch.putMetricAlarm API
 * @param {Array} alarms CloudWatch Alarms to update
 * @returns {Promise} Array of fulfilled promises
 */
const updateAlarms = async (alarms) => {
  const results = [];
  const rate = 870 / alarms.length < 1 ? 870 / alarms.length : 1;
  for (let alarm of alarms) {
    let result = await CloudWatch.send(new PutMetricAlarmCommand(alarm));
    results.push(result);
    await new Promise((resolve) => setTimeout(resolve, rate * 1000));
  }
  return results;
};

/**
 * Removes any autoscaling alarms
 * @param {Object} alarm CloudWatch Alarm
 * @returns {Object} CloudWatch Alarm that passed filtering
 */
// eslint-disable-next-line consistent-return
const alarmFilter = (alarm) => {
  if (alarm.ActionsEnabled) {
    if (
      alarm.AlarmDescription &&
      !alarm.AlarmDescription.startsWith("DO NOT EDIT OR DELETE.")
    ) {
      return alarm;
    }

    if (!alarm.AlarmDescription) {
      return alarm;
    }
  }
};

/**
 * Gets all CloudWatch Alarms
 * @param {Object} cloudwatch AWS CloudWatch Object
 * @returns {Array} CloudWatch Alarms
 */
const getAlarms = async () => {
  let opts = {},
    data = {},
    alarms = [];

  do {
    data = await CloudWatch.send(new DescribeAlarmsCommand(opts));
    alarms = alarms.concat(data.MetricAlarms);
    opts.NextToken = data.NextToken;
  } while (data.NextToken);

  return alarms;
};

/**
 * Wrapping the cfn-response code within a promise
 * @param {Object} event Lambda event
 * @param {Object} context Lambda object
 * @param {String} responseStatus status of response
 * @param {String} reason Failure reason to the CloudFormation response
 * @returns status code of https.request response
 */
const cfResponse = (event, context, responseStatus, reason) => {
  return new Promise((resolve, reject) => {
    const responseBody = JSON.stringify({
      Status: responseStatus,
      Reason: reason || "No reason provided",
      PhysicalResourceId: context.logStreamName,
      StackId: event.StackId,
      RequestId: event.RequestId,
      LogicalResourceId: event.LogicalResourceId,
      NoEcho: false,
    });

    const parsedUrl = url.parse(event.ResponseURL);

    const options = {
      hostname: parsedUrl.hostname,
      port: 443,
      path: parsedUrl.path,
      method: "PUT",
      headers: {
        "content-length": responseBody.length,
      },
    };

    // Make request
    const request = https.request(options, (response) => {
      console.log("Status code: " + response.statusCode);
      resolve(response.statusCode);
    });

    // Catch and throw error from request
    request.on("error", (error) => {
      reject(`HTTPS Request Failed: ${error}`);
    });

    // Write response
    request.write(responseBody);
    request.end();
  });
};
